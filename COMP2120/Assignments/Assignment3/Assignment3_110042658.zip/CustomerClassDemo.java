/*
Assignment 3
Lucas Sarweh
ID: 110042658
COMP-2120
Due: Wed Dec 08 2021
*/

public class CustomerClassDemo {
    public static void main(String[] args){
        Customer julie = new Customer("Julie James", "123 Main Street", "555-1212", "147-A049", true);
        // Print the info
        System.out.println(julie);
    }
}
