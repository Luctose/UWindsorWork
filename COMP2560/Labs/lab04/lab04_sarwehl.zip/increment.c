int increment(int a){
	int b = a;
	b = b + 1;
	return b;
}

