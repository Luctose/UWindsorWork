This project uses UTF-8 encoding. To view properly your terminal must support UTF-8.
VSCode's built in terminal does and also Command Prompt's SimSun-ExtB font does.

Here are some japanese characters if you want to test
(I don't actually know if copy-pasting these into a terminal will cause problems):

食 女　何　僕　一　人　本　時　<- Kanji

しょく　ひと　か　なん　<- Hiragana

ショク　ヒト　カ　ナン　<- Katakana