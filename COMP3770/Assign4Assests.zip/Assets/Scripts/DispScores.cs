using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DispScores : MonoBehaviour
{
    const int lblH = 50;
    const int lblW = 200;
    Rect btnBackMain;
    Rect[] plyLabel;
    Rect[] bossLabel;
    // Start is called before the first frame update
    void Start()
    {
        plyLabel = new Rect[3];
        for(int i = 0; i < 3; ++i){
            plyLabel[i] = new Rect(50, i * lblH, lblW, lblH);
        }
        bossLabel = new Rect[3];
        for(int i = 0; i < 3; ++i){
            bossLabel[i] = new Rect(100, i * lblH, 2 * lblW, lblH);
        }
        // Init button to go back to main menu
        btnBackMain = new Rect(0, 200, 200, 100);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnGUI(){
        // Init the pair of values
        for(int i = 0; i < 3; ++i){
            GUI.Label(plyLabel[i], "0");
        }
        for(int i = 0; i < 3; ++i){
            GUI.Label(bossLabel[i], "0");
        }
        if(GUI.Button(btnBackMain, "Main Menu")){
            SceneManager.LoadScene("MainMenu");
        }
    }
}
