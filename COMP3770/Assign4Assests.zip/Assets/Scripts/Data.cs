using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Data : MonoBehaviour
{
    public GameObject boss;
    public GameObject warrior;
    public GameObject rogue;
    public GameObject mage;
    public GameObject druid;
    public GameObject priest;

    GameObject[] currentObjects;

    void Awake(){
        SceneManager.activeSceneChanged += OnSceneSwitch;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnSceneSwitch(Scene current, Scene next){
        currentObjects = next.GetRootGameObjects();

        for(int i = 0; i < currentObjects.Length; ++i){
                
            if(currentObjects[i].name == "Boss"){
                boss = currentObjects[i];

            }else if(currentObjects[i].name == "Warrior"){
                warrior = currentObjects[i];
                    
            }else if(currentObjects[i].name == "Rogue"){
                rogue = currentObjects[i];
                        
            }else if(currentObjects[i].name == "Mage"){
                mage = currentObjects[i];
                        
            }else if(currentObjects[i].name == "Druid"){
                druid = currentObjects[i];
                        
            }else if(currentObjects[i].name == "Priest"){
                priest = currentObjects[i];
                        
            }
        }
        if(next.name == "MainMenu" || next.name == "Scores"){
            boss = null;
            warrior = null;
            rogue = null;
            mage = null;
            druid = null;
            priest = null;
        }
    }
}
