using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossBhv : MonoBehaviour
{
    public int health = 5000;
    public int tnkdmg;
    public int sqshdmg;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void genWarriorDmg(){

    }

    void genSqshDmg(){

    }
}
