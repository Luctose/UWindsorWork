using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PriestBhv : MonoBehaviour
{
    public int health = 900;
    public int mana = 1000;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
/**
    public void smallHeal(GameObject[] people){
        if(mana >= 5){
            mana -= 5;
            Random rnd = new Random();
            int i = rnd.Next(0, people.Length + 2);
            if(i >= people.Length){
                health += 15;
            }else{
                people[i].health += 15;
            }
        }
    }

    public void bigHeal(GameObject tank){
        if(mana >= 10){
            mana -= 10;
            tank.health += 25;
        }
    }
**/
}
